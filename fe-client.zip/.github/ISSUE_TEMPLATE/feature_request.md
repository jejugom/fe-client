---
name: Feature request
about: 프로젝트에 추가할 기능을 제안
title: '[Feature] '
labels: enhancement
assignees: ''
---

## 기능

<추가할 기능에 대해 구체적 설명>

## 필요한 이유

<왜 이 기능이 필요한지 설명>

## 예상 작업 내용

- [ ] 작업 1
- [ ] 작업 2
