<template>
  <div>
    <h1 class="text-primary-500 mb-4 text-center text-2xl font-bold">
      증여세는 어떻게 계산하나요?</h1
    >

    <div class="space-y-8">
      <div class="bg-primary-100 rounded-2xl p-6 shadow-xl">
        <h2 class="text-primary-500 mb-4 text-lg font-semibold"> 세율 구간 </h2>
        <p class="text-primary-500 mb-4 text-base">
          증여세는 증여받은 재산의 가액에서 각종 공제액을 뺀
          <strong>과세표준</strong>에 따라 5단계의
          <strong class="text-primary-500">초과누진세율</strong>이 적용됩니다.
          과세표준이 높을수록 높은 세율이 적용되어 세금 부담이 커져요.
        </p>

        <div class="overflow-x-auto rounded-xl bg-white">
          <table class="divide-primary-100 w-full divide-y">
            <thead class="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  class="text-primary-500 py-2 text-center font-semibold"
                >
                  과세표준 (10년 합산)
                </th>
                <th
                  scope="col"
                  class="text-primary-500 py-2 text-center font-semibold"
                >
                  세율
                </th>
                <th
                  scope="col"
                  class="text-primary-500 py-2 text-center font-semibold"
                >
                  누진공제액
                </th>
              </tr>
            </thead>
            <tbody class="divide-primary-100 divide-y bg-white">
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  1억 원 이하
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  10%
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  -
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  1억 원 초과 ~ 5억 원 이하
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  20%
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  1,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  5억 원 초과 ~ 10억 원 이하
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  30%
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  6,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  10억 원 초과 ~ 30억 원 이하
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  40%
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  1억 6,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  30억 원 초과
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  50%
                </td>
                <td
                  class="text-primary-500 px-4 py-2 text-center text-sm whitespace-nowrap"
                >
                  4억 6,000만 원
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p class="text-primary-500 mt-8 text-base">
          <strong class="font-bold text-red-500"> * 할증세율 적용: </strong>
          증여자가 사망하기 전 자녀를 건너뛰고 손자녀에게 증여하는 경우,
          세대생략 할증으로
          <strong class="font-bold text-red-500"
            >일반 증여세액에 30%를 가산</strong
          >하여 계산합니다.
        </p>
      </div>

      <div class="bg-primary-100 rounded-2xl p-6 shadow-xl">
        <h2 class="text-primary-500 mb-4 text-lg font-semibold">
          증여재산공제
        </h2>
        <p class="text-primary-500 mb-4 text-base">
          증여세를 계산할 때, 증여자와 수증자 관계에 따라 일정 금액을 공제받을
          수 있습니다. 이 공제는
          <strong class="text-primary-500"
            >10년 내에 동일인에게 증여받은 금액을 모두 합산</strong
          >하여 적용됩니다. 예를 들어, 10년 동안 부모님께 총 1억 원을
          증여받았다면, 5,000만 원까지 공제받을 수 있습니다.
        </p>
        <div class="overflow-x-auto rounded-xl bg-white">
          <table class="divide-primary-100 w-full divide-y">
            <thead class="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  class="text-primary-500 py-2 text-center text-xs font-semibold tracking-wider uppercase"
                >
                  증여자와의 관계
                </th>
                <th
                  scope="col"
                  class="text-primary-500 py-2 text-center text-xs font-semibold tracking-wider uppercase"
                >
                  공제 한도 (10년간 합산)
                </th>
              </tr>
            </thead>
            <tbody class="divide-primary-100 divide-y bg-white">
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  배우자
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  6억 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  직계존속 (성년)
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  5,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  직계존속 (미성년자)
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  2,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  직계비속
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  5,000만 원
                </td>
              </tr>
              <tr>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  기타 친족 (6촌 이내 혈족, 4촌 이내 인척)
                </td>
                <td
                  class="text-primary-500 py-2 text-center text-sm whitespace-nowrap"
                >
                  1,000만 원
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="bg-primary-100 rounded-2xl p-6 shadow-xl">
        <!-- <h2 class="text-primary-500 mb-4 text-lg font-semibold">
          국세청 자료를 참고하세요
        </h2> -->
        <iframe
          class="h-80 w-full"
          src="https://www.youtube.com/embed/eWztSg6_9lU"
          title="(국세매거진) 증여세, 공제 항목 확인하세요~"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
        <div class="mt-4 text-center">
          <a
            href="https://www.nts.go.kr/nts/cm/cntnts/cntntsView.do?mi=2340&cntntsId=7728"
            target="_blank"
            class="text-primary-300 text-sm font-semibold underline"
          >
            🔗 국세청 홈페이지에서 세액계산 흐름도를 확인해 보세요
          </a>
        </div>
      </div>

      <div class="rounded-2xl bg-red-100 p-6 shadow-xl">
        <div class="flex items-start">
          <div class="mt-1 mr-3">
            <svg
              class="h-5 w-5 text-red-500"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fill-rule="evenodd"
                d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                clip-rule="evenodd"
              />
            </svg>
          </div>
          <div>
            <h4 class="mb-1 font-semibold text-red-500">참고사항</h4>
            <p class="text-sm leading-relaxed text-red-500">
              2024년 1월 1일부터 혼인 또는 출산을 이유로 증여받는 경우, 일반
              증여재산공제와 별도로
              <strong class="font-bold">1억 원</strong>까지 추가로 공제받을 수
              있습니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
const openYoutubePopup = () => {
  const url = 'https://www.youtube.com/watch?v=eWztSg6_9lU';
  const name = 'youtube_popup';
  const width = 800;
  const height = 500;
  const left = (window.innerWidth - width) / 2;
  const top = (window.innerHeight - height) / 2;
  const options = `width=${width},height=${height},left=${left},top=${top}`;

  window.open(url, name, options);
};
</script>
