<template>
  <div>
    <div class="mb-6">
      <div
        class="border-primary-100 bg-primary-100 relative overflow-hidden rounded-2xl border p-6 shadow-xl"
      >
        <div class="relative">
          <h3 class="text-primary-500 mb-2 text-lg">예상 증여세 총액</h3>
          <p class="text-primary-500 text-3xl font-bold">
            {{ formatCurrency(totalGiftTax) }}
          </p>
          <div class="text-primary-500 mt-4 mb-4 flex items-center text-sm">
            어떻게 계산되었는지 궁금하신가요? 🤔
          </div>
          <Btn
            color="surface"
            label="증여세 계산 방법 보러가기"
            size="large"
            @click="goToTaxInfo"
          />
        </div>
      </div>
    </div>

    <div class="mb-6">
      <!-- 수증자별 세금 요약표 -->
      <div class="bg-primary-100 rounded-2xl p-6 shadow-xl">
        <div class="mb-2 flex items-center">
          <h3 class="text-primary-500 text-lg">수증자별 세금 요약표</h3>
        </div>

        <div class="mb-4 overflow-hidden rounded-lg bg-white">
          <table class="w-full">
            <thead>
              <tr>
                <th
                  class="border-primary-100 text-primary-500 border-b px-4 py-3 text-center font-semibold"
                >
                  수증자
                </th>
                <th
                  class="border-primary-100 text-primary-500 border-b text-center font-semibold"
                >
                  증여금
                </th>
                <th
                  class="border-primary-100 text-primary-500 border-b text-center font-semibold"
                >
                  예상 증여세
                </th>
              </tr>
            </thead>
            <tbody class="divide-primary-100 divide-y">
              <tr v-for="(recipient, index) in recipientSummaries" :key="index">
                <td>
                  <div class="text-center">
                    <div class="text-primary-500">
                      {{ recipient.recipientName }}
                    </div>
                  </div>
                </td>
                <td class="px-4 py-3 text-center">
                  <div class="text-primary-500 font-semibold">
                    {{ formatCurrency(recipient.totalGiftAmount) }}
                  </div>
                </td>
                <td class="px-4 py-3 text-center">
                  <div class="text-primary-500 font-semibold">
                    {{ formatCurrency(recipient.estimatedTax) }}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 수증자별 증여금, 증여세 비교 차트 -->
        <div class="mb-2 flex items-center">
          <h3 class="text-primary-500 text-lg">수증자별 증여금, 증여세 비교</h3>
        </div>
        <div class="rounded-xl bg-white p-6">
          <div v-if="chartSeries.length > 0">
            <apexchart
              type="bar"
              :options="chartOptions"
              :series="chartSeries"
              height="300"
            ></apexchart>
          </div>
          <div
            v-else
            class="text-primary-500 flex h-64 items-center justify-center"
          >
            <div class="text-center">
              <svg
                class="text-primary-500 mx-auto h-12 w-12"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
              <p class="mt-2">차트 데이터를 불러오는 중...</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 유형별 절세 전략 추천 -->
    <div class="mb-4 grid gap-6">
      <div class="bg-primary-100 rounded-2xl p-6 shadow-xl">
        <div class="mb-2 flex items-center">
          <h3 class="text-primary-500 text-lg">유형별 절세 전략 추천</h3>
        </div>

        <div
          v-for="(strategy, index) in taxSavingStrategies"
          :key="index"
          class="group flex items-start rounded-lg px-3 py-3"
        >
          <!-- 숫자 인덱스 -->
          <div
            class="bg-primary-500 mr-4 flex h-7 w-7 items-center justify-center rounded-full text-sm font-bold text-white"
          >
            {{ index + 1 }}
          </div>

          <!-- 전략 내용 -->
          <div class="flex-1">
            <p class="text-primary-500 text-sm">
              {{ strategy }}
            </p>
          </div>

          <!-- 화살표 아이콘 -->
          <!-- <div class="ml-2">
            <svg
              class="text-primary-500 h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M9 5l7 7-7 7"
              />
            </svg>
          </div> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import VueApexCharts from 'vue3-apexcharts';
import Btn from '@/components/buttons/Btn.vue';

import { formatCurrency } from '@/utils/format';
import { useSimulationStore } from '@/stores/simulation';
import type {
  RecipientTaxDetailDto,
  SimulationRequestDto,
} from '@/types/gift/simulation';

const apexchart = VueApexCharts;
const simulationStore = useSimulationStore();
const router = useRouter();

const goToTaxInfo = () => {
  router.push({ name: 'GiftTaxInfo' });
};

const totalGiftTax = computed(() => simulationStore.totalGiftTax);
const recipientSummaries = computed(() => simulationStore.recipientSummaries);
const taxSavingStrategies = computed(() => simulationStore.taxSavingStrategies);

// 차트 데이터 로직을 수정합니다.
const chartSeries = computed(() => {
  // recipientSummaries.value가 존재하고 데이터가 있을 때만 map()을 실행
  if (!recipientSummaries.value || recipientSummaries.value.length === 0) {
    return [];
  }
  return [
    {
      name: '증여금',
      data: recipientSummaries.value.map(
        (r: RecipientTaxDetailDto) => r.totalGiftAmount
      ),
    },
    {
      name: '예상 증여세',
      data: recipientSummaries.value.map(
        (r: RecipientTaxDetailDto) => r.estimatedTax
      ),
    },
  ];
});

const chartOptions = computed(() => {
  // recipientSummaries.value가 존재하고 데이터가 있을 때만 map()을 실행
  if (!recipientSummaries.value || recipientSummaries.value.length === 0) {
    return {}; // 빈 객체를 반환하여 에러 방지
  }
  return {
    chart: { type: 'bar', height: 350, toolbar: { show: false } },
    plotOptions: {
      bar: { horizontal: false, columnWidth: '55%', endingShape: 'rounded' },
    },
    dataLabels: { enabled: false },
    stroke: { show: true, width: 2, colors: ['transparent'] },
    xaxis: {
      categories: recipientSummaries.value.map(
        (r: RecipientTaxDetailDto) => r.recipientName
      ),
    },
    yaxis: {
      labels: {
        formatter(value: number) {
          if (value >= 100000000) {
            return `${(value / 100000000).toFixed(0)}억 원`;
          }
          if (value >= 10000) {
            return `${(value / 10000).toFixed(0)}만 원`;
          }
          return formatCurrency(value);
        },
      },
    },
    fill: { opacity: 1 },
    tooltip: {
      y: {
        formatter(val: number) {
          return `${formatCurrency(val)}`;
        },
      },
    },
    colors: ['#93C5FD', '#2563EB'],
  };
});
</script>
