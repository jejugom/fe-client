<template>
  <div
    class="bg-surface-400/40 fixed inset-0 z-50 flex flex-col items-center justify-center"
  >
    <!-- 로딩 스피너 -->
    <div
      class="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-yellow-400 border-t-transparent"
    ></div>
    <div class="text-center text-lg leading-snug font-semibold text-white">
      곧 준비됩니다. <br />
      <span class="text-yellow-300">
        행복한 미래를<br />안전하게 설계 중입니다...
      </span>
    </div>
  </div>
</template>

<script setup lang="ts"></script>
