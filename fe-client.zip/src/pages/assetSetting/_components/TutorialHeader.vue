<template>
  <div class="mb-8 text-center">
    <div
      class="mb-4 inline-flex items-center justify-center rounded-full bg-white p-6 shadow-xs"
    >
      <div class="text-3xl font-bold">
        <span class="text-primary-300">노후</span>
        <span class="text-secondary-300">도락</span>
      </div>
    </div>
    <h1 class="text-primary-500 mb-2 text-2xl font-bold">
      스마트한 노후 준비의 시작
    </h1>
    <p class="text-surface-400">
      복잡한 노후 설계를 쉽고 간편하게<br />
      맞춤형 솔루션으로 안내해드립니다
    </p>
  </div>
</template>
