<template>리워드 선택 예약 페이지</template>
