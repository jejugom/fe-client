<template>
  <div v-if="loading" class="flex h-64 items-center justify-center">
    <div class="text-lg">예약 내역을 불러오는 중...</div>
  </div>

  <div v-else class="space-y-4">
    <div class="text-secondary-500 mb-2 text-lg font-semibold">
      예약하신 방문 내용을 확인하세요
    </div>

    <!-- 예약 내역이 있는 경우 -->
    <div v-if="sortedBookings.length > 0" class="space-y-4">
      <RegisterCard 
        v-for="booking in sortedBookings"
        :key="booking.id"
        :booking="booking"
        @updated="refreshBookingData"
      />
    </div>

    <!-- 예약 내역이 없는 경우 -->
    <div v-else class="py-8 text-center text-gray-500">
      예약 내역이 없습니다.
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import RegisterCard from './_components/RegisterCard.vue';
import { mypageApi } from '@/api/user/mypage';

const myPageData = ref(null);
const loading = ref(true);

// Transform booking data from API to match RegisterCard expectations
const transformBookingData = (bookingInfo) => {
  return bookingInfo.map(booking => {
    const date = new Date(booking.date);
    const formattedDate = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    
    return {
      id: booking.bookingId,
      date: formattedDate,
      time: booking.time,
      bank_name: `지점 ID: ${booking.branchId}`, // TODO: 실제 지점명으로 변환 필요
      prdt_name: booking.finPrdtCode // TODO: 실제 상품명으로 변환 필요
    };
  });
};

const bookingItems = computed(() => {
  if (!myPageData.value?.bookingInfo) return [];
  return transformBookingData(myPageData.value.bookingInfo);
});

// 예약 시간이 제일 빠른 순서대로 정렬
const sortedBookings = computed(() => {
  return [...bookingItems.value].sort((a, b) => {
    const dateTimeA = new Date(`${a.date}T${a.time}`);
    const dateTimeB = new Date(`${b.date}T${b.time}`);
    return dateTimeA - dateTimeB;
  });
});

// API 데이터 가져오기
const fetchBookingData = async () => {
  try {
    loading.value = true;
    myPageData.value = await mypageApi.getMyPageData();
  } catch (error) {
    console.error('예약 데이터 로딩 실패:', error);
    // TODO: 에러 처리 로직 추가
  } finally {
    loading.value = false;
  }
};

// 예약 수정/삭제 후 데이터 새로고침
const refreshBookingData = async () => {
  await fetchBookingData();
};

onMounted(() => {
  fetchBookingData();
});
</script>